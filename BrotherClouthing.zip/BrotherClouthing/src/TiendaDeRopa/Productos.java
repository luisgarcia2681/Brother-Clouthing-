/*
 * PROYECTO: Brother Clothing
 * ALUMNO: Luis Gael Garcia Reyes
 * MATERIA: Analisis Y Diseño De Sistemas
 * FECHA: 30 de Noviembre 2025
 * DESCRIPCIÓN: Catálogo visual de la tienda. Gestiona la carga de imágenes, selección de tallas y validación de stock disponible.
 */
package TiendaDeRopa;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.HashMap;
import java.util.Map;
import javax.imageio.ImageIO;
import javax.swing.border.EmptyBorder;
import java.sql.*;
import java.awt.image.BufferedImage;

public class Productos extends JFrame {

    private static final long serialVersionUID = 1L;
    
    private JComboBox<String> productComboBox;
    private JComboBox<String> sizeComboBox;
    private JPanel orderListPanel; 
    private JLabel lblImagenProducto; 
    private JLabel lblEstado;
    private JLabel lblPrecio;
    private JLabel lblCategoria;

    private Map<String, String[]> productSizes;
    private Map<String, String> productImages;
    private Map<String, Double> productPrices;
    private Map<String, String> productCategories;
    
    private Map<String, Integer> carritoCantidad; 
    
    private final String[] apparelSizes = {"S", "M", "L", "XL"};
    private final String[] shoeSizes = {"4mx", "5mx", "6mx", "7mx", "8mx", "9mx"};
    
    private final Color COLOR_BG = new Color(245, 247, 249);
    private final Color COLOR_BTN = new Color(96, 125, 139);
    
    private int idUsuarioActual;

    public Productos() {
        this(0);
    }

    public Productos(int idUsuario) {
        this.idUsuarioActual = idUsuario;
        this.carritoCantidad = new HashMap<>();
        
        setTitle("Catálogo - Brother Clothing");
        setSize(950, 700); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(COLOR_BG);
        setLayout(new BorderLayout(15, 15));

        cargarProductosDesdeDB();
        initUI();
        
        SwingUtilities.invokeLater(this::updateProductView);
    }

    public Productos(String ordenActual, int idUsuario) {
        this(idUsuario);
        reconstruirOrdenDesdeTexto(ordenActual);
    }

    private void cargarProductosDesdeDB() {
        productSizes = new HashMap<>();
        productImages = new HashMap<>();
        productPrices = new HashMap<>();
        productCategories = new HashMap<>();

        ConexionMySQL conexion = new ConexionMySQL();
        String sql = "SELECT nombre, precio, tipo_talla, stock FROM Productos";

        try (Connection con = conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String nombre = rs.getString("nombre");
                double precio = rs.getDouble("precio");
                String tipoTalla = rs.getString("tipo_talla");
                int stock = rs.getInt("stock");

                if (tipoTalla != null && !tipoTalla.isEmpty()) {
                    tipoTalla = tipoTalla.substring(0, 1).toUpperCase() + tipoTalla.substring(1).toLowerCase();
                }

                if (stock <= 0) {
                    nombre = nombre + " (AGOTADO)";
                    productPrices.put(nombre, 0.0);
                } else {
                    productPrices.put(nombre, precio);
                }
                
                productCategories.put(nombre, tipoTalla);

                if ("Ropa".equals(tipoTalla)) {
                    productSizes.put(nombre, apparelSizes);
                } else if ("Calzado".equals(tipoTalla)) {
                    productSizes.put(nombre, shoeSizes);
                }
            }
        } catch (SQLException ex) {
            System.err.println("Error BD: " + ex.getMessage());
        }

        String rutaBase = "imagenesbrotherclouthing/"; 
        
        productImages.put("Camisa Baby Tee", rutaBase + "Baby Tee.png");
        productImages.put("Camisa Boxy Fit", rutaBase + "Boxy Fit.png");
        productImages.put("Camisa Regular Fit", rutaBase + "Regular Fit.png");
        productImages.put("Pantalon Baggy", rutaBase + "Baggy.png");
        productImages.put("Pantalon Flared", rutaBase + "Flare.png");
        productImages.put("Pantalon Recto", rutaBase + "Recto.png");
        productImages.put("Sudadera Basica", rutaBase + "Basic.png");
        productImages.put("Chamarra Basica", rutaBase + "Chamarra.png");
        productImages.put("Sudadera con Print", rutaBase + "Sudadera Print.png");
        productImages.put("Zapatos Dr Martens", rutaBase + "Dr. M.png");
        productImages.put("Tenis Adidas", rutaBase + "Samba.png");
        productImages.put("Botas Timberland", rutaBase + "Timbs.png");
    }

    private void initUI() {
        JPanel leftPanel = new JPanel(new GridBagLayout());
        leftPanel.setBackground(COLOR_BG);
        leftPanel.setBorder(new EmptyBorder(10, 20, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0; gbc.gridy = 0;

        JPanel imageContainer = new JPanel(new BorderLayout());
        imageContainer.setPreferredSize(new Dimension(300, 250));
        imageContainer.setBackground(Color.WHITE);
        imageContainer.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        lblImagenProducto = new JLabel("Cargando...", SwingConstants.CENTER);
        imageContainer.add(lblImagenProducto);
        
        gbc.gridwidth = 2; leftPanel.add(imageContainer, gbc);

        gbc.gridy++; gbc.gridwidth = 1; leftPanel.add(new JLabel("Producto:"), gbc);
        String[] productosArray = productPrices.keySet().toArray(new String[0]);
        if (productosArray.length == 0) productosArray = new String[]{"Sin productos"};
        productComboBox = new JComboBox<>(productosArray);
        gbc.gridx = 1; leftPanel.add(productComboBox, gbc);
        
        gbc.gridx = 0; gbc.gridy++; leftPanel.add(new JLabel("Categoría:"), gbc);
        gbc.gridx = 1; 
        lblCategoria = new JLabel("-");
        lblCategoria.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblCategoria.setForeground(Color.DARK_GRAY);
        leftPanel.add(lblCategoria, gbc);

        gbc.gridx = 0; gbc.gridy++; leftPanel.add(new JLabel("Talla:"), gbc);
        gbc.gridx = 1;
        sizeComboBox = new JComboBox<>();
        leftPanel.add(sizeComboBox, gbc);

        gbc.gridx = 0; gbc.gridy++; leftPanel.add(new JLabel("Precio:"), gbc);
        gbc.gridx = 1;
        lblPrecio = new JLabel("$0.00");
        lblPrecio.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblPrecio.setForeground(new Color(0, 100, 0));
        leftPanel.add(lblPrecio, gbc);

        gbc.gridx = 0; gbc.gridy++; gbc.gridwidth = 2;
        JButton btnAdd = new JButton("AGREGAR AL CARRITO");
        styleBtn(btnAdd, COLOR_BTN);
        leftPanel.add(btnAdd, gbc);

        add(leftPanel, BorderLayout.WEST);

        JPanel rightPanel = new JPanel(new BorderLayout(10, 10));
        rightPanel.setBackground(COLOR_BG);
        rightPanel.setBorder(new EmptyBorder(10, 10, 10, 20));
        JLabel lblTitle = new JLabel("Tu Orden Actual");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        rightPanel.add(lblTitle, BorderLayout.NORTH);

        orderListPanel = new JPanel();
        orderListPanel.setLayout(new BoxLayout(orderListPanel, BoxLayout.Y_AXIS));
        orderListPanel.setBackground(Color.WHITE);
        JScrollPane scroll = new JScrollPane(orderListPanel);
        scroll.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        rightPanel.add(scroll, BorderLayout.CENTER);

        JButton btnPagar = new JButton("VER ORDEN Y PAGAR");
        styleBtn(btnPagar, new Color(46, 204, 113));
        rightPanel.add(btnPagar, BorderLayout.SOUTH);

        add(rightPanel, BorderLayout.CENTER);

        lblEstado = new JLabel("Listo", SwingConstants.LEFT);
        lblEstado.setBorder(new EmptyBorder(5, 10, 5, 10));
        lblEstado.setOpaque(true);
        lblEstado.setBackground(new Color(230, 230, 230));
        add(lblEstado, BorderLayout.SOUTH);

        productComboBox.addActionListener(e -> updateProductView());

        btnAdd.addActionListener(e -> {
            String prod = (String) productComboBox.getSelectedItem();
            String size = (String) sizeComboBox.getSelectedItem();
            
            if (prod == null) return;

            String nombreLimpio = prod.replace(" (AGOTADO)", "").trim();

            if (prod.contains("(AGOTADO)")) {
                lblEstado.setText("PRODUCTO NO DISPONIBLE (Stock Agotado)");
                lblEstado.setForeground(Color.RED);
                return;
            }

            int stockReal = verificarStock(nombreLimpio);
            int enCarrito = carritoCantidad.getOrDefault(nombreLimpio, 0);

            if (enCarrito + 1 > stockReal) {
                lblEstado.setText("Stock insuficiente. Solo quedan " + stockReal + " unidades.");
                lblEstado.setForeground(Color.RED);
                return;
            }

            if (productPrices.containsKey(prod)) {
                Double price = productPrices.get(prod);
                
                String productText = String.format("%s - Talla: %s - Precio: %.2f", nombreLimpio, size, price);
                agregarProductoALista(productText);
                
                lblEstado.setText("Producto agregado: " + nombreLimpio);
                lblEstado.setForeground(new Color(0, 100, 0));
            }
        });

        btnPagar.addActionListener(e -> {
            String ordenCompleta = construirTextoOrden();
            if (ordenCompleta.isEmpty()) {
                lblEstado.setText("Error: La orden está vacía.");
                lblEstado.setForeground(Color.RED);
            } else {
                VistaOrden vista = new VistaOrden(ordenCompleta, idUsuarioActual);
                vista.setVisible(true);
                this.dispose();
            }
        });
    }
    
    private int verificarStock(String nombreProducto) {
        int stock = 0;
        try (Connection con = new ConexionMySQL().conectar();
             PreparedStatement ps = con.prepareStatement("SELECT stock FROM productos WHERE nombre = ?")) {
            ps.setString(1, nombreProducto);
            ResultSet rs = ps.executeQuery();
            if(rs.next()) {
                stock = rs.getInt("stock");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return stock;
    }

    private void agregarProductoALista(String textoProducto) {
        String nombreProd = textoProducto.split(" - ")[0].trim();
        
        carritoCantidad.put(nombreProd, carritoCantidad.getOrDefault(nombreProd, 0) + 1);

        JPanel itemPanel = new JPanel(new BorderLayout(10, 0));
        itemPanel.setBackground(Color.WHITE);
        itemPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, Color.LIGHT_GRAY),
            new EmptyBorder(8, 10, 8, 5)
        ));
        itemPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));

        JLabel lblTexto = new JLabel(textoProducto);
        lblTexto.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        JButton btnEliminar = new JButton("X");
        btnEliminar.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnEliminar.setForeground(Color.WHITE);
        btnEliminar.setBackground(new Color(231, 76, 60)); 
        btnEliminar.setFocusPainted(false);
        btnEliminar.setBorderPainted(false);
        btnEliminar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnEliminar.setPreferredSize(new Dimension(40, 25));
        
        btnEliminar.addActionListener(e -> {
            if (carritoCantidad.containsKey(nombreProd)) {
                int actual = carritoCantidad.get(nombreProd);
                if (actual > 0) {
                    carritoCantidad.put(nombreProd, actual - 1);
                }
            }
            
            orderListPanel.remove(itemPanel);
            orderListPanel.revalidate();
            orderListPanel.repaint();
            lblEstado.setText("Producto eliminado.");
            lblEstado.setForeground(Color.RED);
        });

        itemPanel.add(lblTexto, BorderLayout.CENTER);
        itemPanel.add(btnEliminar, BorderLayout.EAST);

        orderListPanel.add(itemPanel);
        orderListPanel.revalidate();
        orderListPanel.repaint();
        
        JScrollBar vertical = ((JScrollPane)orderListPanel.getParent().getParent()).getVerticalScrollBar();
        vertical.setValue(vertical.getMaximum());
    }

    private String construirTextoOrden() {
        StringBuilder orden = new StringBuilder();
        for (Component comp : orderListPanel.getComponents()) {
            if (comp instanceof JPanel) {
                JPanel itemPanel = (JPanel) comp;
                for (Component innerComp : itemPanel.getComponents()) {
                    if (innerComp instanceof JLabel) {
                        orden.append(((JLabel) innerComp).getText()).append("\n");
                        break;
                    }
                }
            }
        }
        return orden.toString();
    }
    
    private void reconstruirOrdenDesdeTexto(String ordenTexto) {
        if (ordenTexto != null && !ordenTexto.isEmpty()) {
            String[] lineas = ordenTexto.split("\n");
            for (String linea : lineas) {
                if (!linea.trim().isEmpty()) {
                    agregarProductoALista(linea);
                }
            }
        }
    }

    private void updateProductView() {
        String selectedProduct = (String) productComboBox.getSelectedItem();
        if (selectedProduct != null) {
            if (productSizes.containsKey(selectedProduct)) {
                String[] sizes = productSizes.get(selectedProduct);
                sizeComboBox.setModel(new DefaultComboBoxModel<>(sizes));
            }
            
            actualizarImagen(selectedProduct);
            
            if (productPrices.containsKey(selectedProduct)) {
                Double precio = productPrices.get(selectedProduct);
                lblPrecio.setText(String.format("$%.2f", precio));
            }
            
            String nombreLimpio = selectedProduct.replace(" (AGOTADO)", "").trim();
            if(productCategories.containsKey(nombreLimpio)) {
                lblCategoria.setText(productCategories.get(nombreLimpio));
            }
        }
    }

    private void actualizarImagen(String nombreProducto) {
        String nombreLimpio = nombreProducto.replace(" (AGOTADO)", "").trim();
        String ruta = productImages.get(nombreLimpio);
        
        if (ruta == null) {
             for (String key : productImages.keySet()) {
                 if (nombreLimpio.contains(key) || key.contains(nombreLimpio)) {
                     ruta = productImages.get(key);
                     break;
                 }
             }
        }

        lblImagenProducto.setIcon(null);
        lblImagenProducto.setText("Cargando...");

        if (ruta != null) {
            try {
                File imgFile = new File(ruta);
                if (imgFile.exists()) {
                    BufferedImage originalImage = ImageIO.read(imgFile);
                    if (originalImage != null) {
                        Image scaledImage = originalImage.getScaledInstance(300, 250, Image.SCALE_SMOOTH);
                        lblImagenProducto.setIcon(new ImageIcon(scaledImage));
                        lblImagenProducto.setText("");
                    }
                } else {
                    lblImagenProducto.setText("Imagen no encontrada");
                }
            } catch (Exception e) {
                lblImagenProducto.setText("Error al leer archivo");
            }
        } else {
            lblImagenProducto.setText("Sin imagen");
        }
    }

    private void styleBtn(JButton btn, Color color) {
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(0, 40));
    }
}