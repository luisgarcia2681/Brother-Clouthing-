/*
 * PROYECTO: Brother Clothing
 * ALUMNO: Luis Gael Garcia Reyes
 * MATERIA: Analisis Y Diseño De Sistemas
 * FECHA: 30 de Noviembre 2025
 * DESCRIPCIÓN: Panel administrativo (CRUD). Permite la gestión total de Usuarios, Inventario de Productos, Direcciones y Pedidos.
 * CONTRASEÑA DE ACCESO: admin123
 */
package TiendaDeRopa;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AdminPanel extends JFrame {

    private static final long serialVersionUID = 1L;
    private JTabbedPane tabbedPane;
    
    private DefaultTableModel modelUsuarios, modelProductos, modelPedidos, modelDirecciones;
    private JTable tableUsuarios, tableProductos, tablePedidos, tableDirecciones;

    private String selectedUserId = null;
    private String selectedProdId = null;
    private String selectedPedId = null;
    private String selectedDirId = null;

    private JTextField txtUserNombre, txtUserEmail, txtUserPass;
    private JLabel lblMsgUsuario;

    private JTextField txtProdNombre, txtProdPrecio, txtProdStock;
    private JComboBox<String> cbProdTipo;
    private JLabel lblMsgProducto;

    private JTextField txtPedCliente, txtPedTotal, txtPedDir, txtPedTel; 
    private JComboBox<String> cbPedEstado; 
    private JLabel lblMsgPedido;

    private JTextField txtDirUserId, txtDirNombre, txtDirCalle, txtDirTel;
    private JLabel lblMsgDireccion;

    private final Color COLOR_BG_MAIN = new Color(245, 247, 249);
    private final Color COLOR_SIDEBAR = Color.WHITE;
    private final Color COLOR_PRIMARY = new Color(52, 73, 94);
    private final Color COLOR_SUCCESS = new Color(39, 174, 96);
    private final Color COLOR_DANGER = new Color(192, 57, 43);
    private final Color COLOR_TEXT_LABEL = new Color(100, 100, 100);

    public AdminPanel() {
        setTitle("Panel de Administración - Brother Clothing");
        setSize(1200, 750);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        setLocationRelativeTo(null);
        getContentPane().setBackground(COLOR_BG_MAIN);

        UIManager.put("TabbedPane.selected", Color.WHITE);
        UIManager.put("TabbedPane.contentBorderInsets", new Insets(0,0,0,0));
        
        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tabbedPane.setBackground(new Color(230, 230, 230));
        tabbedPane.setFocusable(false);

        tabbedPane.addTab("  Clientes  ", crearPanelUsuarios());
        tabbedPane.addTab("  Direcciones  ", crearPanelDirecciones());
        tabbedPane.addTab("  Inventario  ", crearPanelProductos());
        tabbedPane.addTab("  Pedidos  ", crearPanelPedidos());

        add(tabbedPane);
        
        SwingUtilities.invokeLater(() -> {
            cargarUsuarios();
            cargarDirecciones();
            cargarProductos();
            cargarPedidos();
        });
    }

    private JPanel crearPanelUsuarios() {
        JPanel panel = new JPanel(new BorderLayout());
        lblMsgUsuario = crearLabelMensaje();
        panel.add(lblMsgUsuario, BorderLayout.NORTH);

        JPanel formPanel = crearPanelFormulario("Gestión de Clientes");
        
        txtUserNombre = crearTextField(true);
        txtUserEmail = crearTextField(true);
        txtUserPass = crearTextField(true);

        agregarCampo(formPanel, "Nombre Completo:", txtUserNombre);
        agregarCampo(formPanel, "Correo Electrónico:", txtUserEmail);
        agregarCampo(formPanel, "Contraseña:", txtUserPass);

        JPanel btnPanel = crearPanelBotones();
        JButton btnAdd = crearBoton("REGISTRAR", COLOR_SUCCESS);
        JButton btnUpdate = crearBoton("ACTUALIZAR", COLOR_PRIMARY);
        JButton btnDelete = crearBoton("ELIMINAR", COLOR_DANGER);
        JButton btnClear = crearBoton("LIMPIAR", Color.GRAY);

        btnPanel.add(btnAdd); btnPanel.add(btnUpdate); btnPanel.add(btnDelete); btnPanel.add(btnClear);
        formPanel.add(btnPanel);

        modelUsuarios = new DefaultTableModel(new String[]{"ID", "Nombre", "Email", "Password"}, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tableUsuarios = crearTabla(modelUsuarios);
        
        tableUsuarios.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int fila = tableUsuarios.getSelectedRow();
                if (fila != -1) {
                    selectedUserId = modelUsuarios.getValueAt(fila, 0).toString();
                    txtUserNombre.setText(modelUsuarios.getValueAt(fila, 1).toString());
                    txtUserEmail.setText(modelUsuarios.getValueAt(fila, 2).toString());
                    txtUserPass.setText(modelUsuarios.getValueAt(fila, 3).toString());
                    mostrarMensaje(lblMsgUsuario, "Cliente seleccionado (ID: " + selectedUserId + ")", false);
                }
            }
        });

        btnAdd.addActionListener(e -> agregarUsuario());
        btnUpdate.addActionListener(e -> actualizarUsuario());
        btnDelete.addActionListener(e -> eliminarUsuario());
        btnClear.addActionListener(e -> { limpiarFormUsuarios(); selectedUserId = null; });

        panel.add(crearSplit(formPanel, new JScrollPane(tableUsuarios)), BorderLayout.CENTER);
        return panel;
    }

    private JPanel crearPanelDirecciones() {
        JPanel panel = new JPanel(new BorderLayout());
        lblMsgDireccion = crearLabelMensaje();
        panel.add(lblMsgDireccion, BorderLayout.NORTH);

        JPanel formPanel = crearPanelFormulario("Direcciones de Envío");

        txtDirUserId = crearTextField(true);
        agregarValidacionNumerica(txtDirUserId);
        txtDirNombre = crearTextField(true);
        txtDirCalle = crearTextField(true);
        txtDirTel = crearTextField(true);
        agregarValidacionNumerica(txtDirTel);

        agregarCampo(formPanel, "ID Usuario (Dueño):", txtDirUserId);
        agregarCampo(formPanel, "Destinatario:", txtDirNombre);
        agregarCampo(formPanel, "Calle y Número:", txtDirCalle);
        agregarCampo(formPanel, "Teléfono:", txtDirTel);

        JPanel btnPanel = crearPanelBotones();
        JButton btnAdd = crearBoton("AGREGAR", COLOR_SUCCESS);
        JButton btnUpdate = crearBoton("ACTUALIZAR", COLOR_PRIMARY);
        JButton btnDelete = crearBoton("ELIMINAR", COLOR_DANGER);
        JButton btnClear = crearBoton("LIMPIAR", Color.GRAY);
        btnPanel.add(btnAdd); btnPanel.add(btnUpdate); btnPanel.add(btnDelete); btnPanel.add(btnClear);
        formPanel.add(btnPanel);

        modelDirecciones = new DefaultTableModel(new String[]{"ID", "ID Usuario", "Destinatario", "Dirección", "Teléfono"}, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tableDirecciones = crearTabla(modelDirecciones);
        tableDirecciones.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int fila = tableDirecciones.getSelectedRow();
                if (fila != -1) {
                    selectedDirId = modelDirecciones.getValueAt(fila, 0).toString();
                    txtDirUserId.setText(modelDirecciones.getValueAt(fila, 1).toString());
                    txtDirNombre.setText(modelDirecciones.getValueAt(fila, 2).toString());
                    txtDirCalle.setText(modelDirecciones.getValueAt(fila, 3).toString());
                    txtDirTel.setText(modelDirecciones.getValueAt(fila, 4).toString());
                    mostrarMensaje(lblMsgDireccion, "Dirección seleccionada.", false);
                }
            }
        });

        btnAdd.addActionListener(e -> agregarDireccion());
        btnUpdate.addActionListener(e -> actualizarDireccion());
        btnDelete.addActionListener(e -> eliminarDireccion());
        btnClear.addActionListener(e -> { limpiarFormDirecciones(); selectedDirId = null; });

        panel.add(crearSplit(formPanel, new JScrollPane(tableDirecciones)), BorderLayout.CENTER);
        return panel;
    }

    private JPanel crearPanelProductos() {
        JPanel panel = new JPanel(new BorderLayout());
        lblMsgProducto = crearLabelMensaje();
        panel.add(lblMsgProducto, BorderLayout.NORTH);

        JPanel formPanel = crearPanelFormulario("Control de Inventario");

        txtProdNombre = crearTextField(true);
        txtProdPrecio = crearTextField(true);
        txtProdStock = crearTextField(true);
        agregarValidacionNumerica(txtProdPrecio);
        agregarValidacionNumerica(txtProdStock);
        
        cbProdTipo = new JComboBox<>(new String[]{"Ropa", "Calzado"}); 
        cbProdTipo.setBackground(Color.WHITE);

        agregarCampo(formPanel, "Nombre:", txtProdNombre);
        agregarCampo(formPanel, "Precio ($):", txtProdPrecio);
        agregarCampo(formPanel, "Stock (Cant):", txtProdStock);
        
        JPanel pCombo = new JPanel(new BorderLayout());
        pCombo.setBackground(COLOR_SIDEBAR);
        JLabel l = new JLabel("Categoría:"); l.setFont(new Font("Segoe UI", Font.BOLD, 12)); l.setForeground(COLOR_TEXT_LABEL);
        pCombo.add(l, BorderLayout.NORTH);
        pCombo.add(cbProdTipo, BorderLayout.CENTER);
        pCombo.setBorder(new EmptyBorder(0,0,15,0));
        formPanel.add(pCombo);

        JPanel btnPanel = crearPanelBotones();
        JButton btnAdd = crearBoton("AGREGAR", COLOR_SUCCESS);
        JButton btnUpdate = crearBoton("ACTUALIZAR", COLOR_PRIMARY);
        JButton btnDelete = crearBoton("ELIMINAR", COLOR_DANGER);
        JButton btnClear = crearBoton("LIMPIAR", Color.GRAY);
        btnPanel.add(btnAdd); btnPanel.add(btnUpdate); btnPanel.add(btnDelete); btnPanel.add(btnClear);
        formPanel.add(btnPanel);

        modelProductos = new DefaultTableModel(new String[]{"ID", "Nombre", "Precio", "Stock", "Tipo"}, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tableProductos = crearTabla(modelProductos);
        tableProductos.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int fila = tableProductos.getSelectedRow();
                if (fila != -1) {
                    selectedProdId = modelProductos.getValueAt(fila, 0).toString();
                    txtProdNombre.setText(modelProductos.getValueAt(fila, 1).toString());
                    txtProdPrecio.setText(modelProductos.getValueAt(fila, 2).toString());
                    txtProdStock.setText(modelProductos.getValueAt(fila, 3).toString());
                    
                    String tipo = modelProductos.getValueAt(fila, 4).toString();
                    if(tipo.equalsIgnoreCase("ropa")) cbProdTipo.setSelectedItem("Ropa");
                    else if(tipo.equalsIgnoreCase("calzado")) cbProdTipo.setSelectedItem("Calzado");
                    
                    mostrarMensaje(lblMsgProducto, "Producto cargado.", false);
                }
            }
        });

        btnAdd.addActionListener(e -> agregarProducto());
        btnUpdate.addActionListener(e -> actualizarProducto());
        btnDelete.addActionListener(e -> eliminarProducto());
        btnClear.addActionListener(e -> { limpiarFormProductos(); selectedProdId = null; });

        panel.add(crearSplit(formPanel, new JScrollPane(tableProductos)), BorderLayout.CENTER);
        return panel;
    }

    private JPanel crearPanelPedidos() {
        JPanel panel = new JPanel(new BorderLayout());
        lblMsgPedido = crearLabelMensaje();
        panel.add(lblMsgPedido, BorderLayout.NORTH);

        JPanel formPanel = crearPanelFormulario("Gestión de Pedidos");

        txtPedCliente = crearTextField(false);
        txtPedDir = crearTextField(true); 
        txtPedTel = crearTextField(true); 
        txtPedTotal = crearTextField(false);
        
        cbPedEstado = new JComboBox<>(new String[]{"En Camino", "Entregado", "Cancelado"});
        cbPedEstado.setBackground(Color.WHITE);

        agregarCampo(formPanel, "Cliente:", txtPedCliente);
        agregarCampo(formPanel, "Dirección Envío:", txtPedDir);
        agregarCampo(formPanel, "Teléfono:", txtPedTel);
        agregarCampo(formPanel, "Total ($):", txtPedTotal);
        
        JPanel pEstado = new JPanel(new BorderLayout());
        pEstado.setBackground(COLOR_SIDEBAR);
        JLabel l = new JLabel("Estado del Envío:"); l.setFont(new Font("Segoe UI", Font.BOLD, 12)); l.setForeground(COLOR_TEXT_LABEL);
        pEstado.add(l, BorderLayout.NORTH);
        pEstado.add(cbPedEstado, BorderLayout.CENTER);
        pEstado.setBorder(new EmptyBorder(0,0,15,0));
        formPanel.add(pEstado);

        JPanel btnPanel = crearPanelBotones();
        JButton btnUpdate = crearBoton("Guardar Cambios", COLOR_PRIMARY);
        JButton btnDelete = crearBoton("Borrar Historial", COLOR_DANGER);
        btnPanel.add(btnUpdate); btnPanel.add(btnDelete);
        formPanel.add(btnPanel);

        modelPedidos = new DefaultTableModel(new String[]{"ID", "Cliente", "Dirección", "Teléfono", "Total", "Fecha", "Estado"}, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tablePedidos = crearTabla(modelPedidos);
        tablePedidos.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int fila = tablePedidos.getSelectedRow();
                if (fila != -1) {
                    selectedPedId = modelPedidos.getValueAt(fila, 0).toString();
                    txtPedCliente.setText(modelPedidos.getValueAt(fila, 1).toString());
                    txtPedDir.setText(modelPedidos.getValueAt(fila, 2).toString());
                    txtPedTel.setText(modelPedidos.getValueAt(fila, 3).toString());
                    txtPedTotal.setText(modelPedidos.getValueAt(fila, 4).toString());
                    
                    String estado = modelPedidos.getValueAt(fila, 6).toString();
                    cbPedEstado.setSelectedItem(estado);
                    mostrarMensaje(lblMsgPedido, "Pedido cargado.", false);
                }
            }
        });

        btnUpdate.addActionListener(e -> actualizarPedido());
        btnDelete.addActionListener(e -> eliminarPedido());

        panel.add(crearSplit(formPanel, new JScrollPane(tablePedidos)), BorderLayout.CENTER);
        return panel;
    }


    private void cargarUsuarios() {
        modelUsuarios.setRowCount(0);
        try (Connection con = new ConexionMySQL().conectar();
             ResultSet rs = con.createStatement().executeQuery("SELECT * FROM usuarios")) {
            while (rs.next()) {
                modelUsuarios.addRow(new Object[]{
                    rs.getInt("id"), rs.getString("nombre"), rs.getString("email"), rs.getString("password")
                });
            }
        } catch (Exception e) { mostrarMensaje(lblMsgUsuario, "Error BD: " + e.getMessage(), true); }
    }
    private void agregarUsuario() {
        if(txtUserNombre.getText().isEmpty()) { mostrarMensaje(lblMsgUsuario, "Falta nombre.", true); return; }
        try (Connection con = new ConexionMySQL().conectar();
             PreparedStatement ps = con.prepareStatement("INSERT INTO usuarios (nombre, email, password) VALUES (?,?,?)")) {
            ps.setString(1, txtUserNombre.getText());
            ps.setString(2, txtUserEmail.getText());
            ps.setString(3, txtUserPass.getText());
            ps.executeUpdate();
            mostrarMensaje(lblMsgUsuario, "Usuario registrado.", false);
            cargarUsuarios(); limpiarFormUsuarios();
        } catch (Exception e) { mostrarMensaje(lblMsgUsuario, "Error: " + e.getMessage(), true); }
    }
    private void actualizarUsuario() {
        if (selectedUserId == null) return;
        try (Connection con = new ConexionMySQL().conectar();
             PreparedStatement ps = con.prepareStatement("UPDATE usuarios SET nombre=?, email=?, password=? WHERE id=?")) {
            ps.setString(1, txtUserNombre.getText());
            ps.setString(2, txtUserEmail.getText());
            ps.setString(3, txtUserPass.getText());
            ps.setString(4, selectedUserId);
            ps.executeUpdate();
            mostrarMensaje(lblMsgUsuario, "Usuario actualizado.", false);
            cargarUsuarios(); limpiarFormUsuarios(); selectedUserId = null;
        } catch (Exception e) { mostrarMensaje(lblMsgUsuario, "Error: " + e.getMessage(), true); }
    }
    private void eliminarUsuario() {
        if (selectedUserId == null) return;
        try (Connection con = new ConexionMySQL().conectar();
             PreparedStatement ps = con.prepareStatement("DELETE FROM usuarios WHERE id=?")) {
            ps.setString(1, selectedUserId);
            ps.executeUpdate();
            mostrarMensaje(lblMsgUsuario, "Usuario eliminado.", false);
            cargarUsuarios(); limpiarFormUsuarios(); selectedUserId = null;
        } catch (Exception e) { mostrarMensaje(lblMsgUsuario, "Error: " + e.getMessage(), true); }
    }

    private void cargarDirecciones() {
        modelDirecciones.setRowCount(0);
        try (Connection con = new ConexionMySQL().conectar();
             ResultSet rs = con.createStatement().executeQuery("SELECT * FROM datos_envio")) {
            while (rs.next()) {
                modelDirecciones.addRow(new Object[]{
                    rs.getInt("id_direccion"), rs.getInt("id_usuario"), rs.getString("nombre_destinatario"), 
                    rs.getString("direccion"), rs.getString("telefono")
                });
            }
        } catch (Exception e) {}
    }
    private void agregarDireccion() {
        try (Connection con = new ConexionMySQL().conectar();
             PreparedStatement ps = con.prepareStatement("INSERT INTO datos_envio (id_usuario, nombre_destinatario, direccion, telefono) VALUES (?,?,?,?)")) {
            ps.setInt(1, Integer.parseInt(txtDirUserId.getText()));
            ps.setString(2, txtDirNombre.getText());
            ps.setString(3, txtDirCalle.getText());
            ps.setString(4, txtDirTel.getText());
            ps.executeUpdate();
            mostrarMensaje(lblMsgDireccion, "Dirección agregada.", false);
            cargarDirecciones(); limpiarFormDirecciones();
        } catch (Exception e) { mostrarMensaje(lblMsgDireccion, "Error: " + e.getMessage(), true); }
    }
    private void actualizarDireccion() {
        if (selectedDirId == null) return;
        try (Connection con = new ConexionMySQL().conectar();
             PreparedStatement ps = con.prepareStatement("UPDATE datos_envio SET id_usuario=?, nombre_destinatario=?, direccion=?, telefono=? WHERE id_direccion=?")) {
            ps.setInt(1, Integer.parseInt(txtDirUserId.getText()));
            ps.setString(2, txtDirNombre.getText());
            ps.setString(3, txtDirCalle.getText());
            ps.setString(4, txtDirTel.getText());
            ps.setString(5, selectedDirId); // WHERE
            ps.executeUpdate();
            mostrarMensaje(lblMsgDireccion, "Dirección actualizada.", false);
            cargarDirecciones(); limpiarFormDirecciones(); selectedDirId = null;
        } catch (Exception e) { mostrarMensaje(lblMsgDireccion, "Error: " + e.getMessage(), true); }
    }
    private void eliminarDireccion() {
        if (selectedDirId == null) return;
        try (Connection con = new ConexionMySQL().conectar();
             PreparedStatement ps = con.prepareStatement("DELETE FROM datos_envio WHERE id_direccion=?")) {
            ps.setString(1, selectedDirId);
            ps.executeUpdate();
            mostrarMensaje(lblMsgDireccion, "Dirección borrada.", false);
            cargarDirecciones(); limpiarFormDirecciones(); selectedDirId = null;
        } catch (Exception e) { mostrarMensaje(lblMsgDireccion, "Error: " + e.getMessage(), true); }
    }

    private void cargarProductos() {
        modelProductos.setRowCount(0);
        try (Connection con = new ConexionMySQL().conectar();
             ResultSet rs = con.createStatement().executeQuery("SELECT * FROM productos")) {
            while (rs.next()) {
                int stock = rs.getInt("stock");
                String tipo = rs.getString("tipo_talla");
                if(tipo != null && !tipo.isEmpty()) 
                    tipo = tipo.substring(0, 1).toUpperCase() + tipo.substring(1).toLowerCase();
                modelProductos.addRow(new Object[]{
                    rs.getInt("id_producto"), rs.getString("nombre"), rs.getDouble("precio"), stock, tipo
                });
            }
        } catch (Exception e) {}
    }
    private void agregarProducto() {
        if (txtProdNombre.getText().isEmpty()) return;
        try (Connection con = new ConexionMySQL().conectar();
             PreparedStatement ps = con.prepareStatement("INSERT INTO productos (nombre, precio, stock, tipo_talla) VALUES (?,?,?,?)")) {
            ps.setString(1, txtProdNombre.getText());
            ps.setDouble(2, Double.parseDouble(txtProdPrecio.getText()));
            ps.setInt(3, Integer.parseInt(txtProdStock.getText()));
            ps.setString(4, cbProdTipo.getSelectedItem().toString());
            ps.executeUpdate();
            mostrarMensaje(lblMsgProducto, "Producto agregado.", false);
            cargarProductos(); limpiarFormProductos();
        } catch (Exception e) { mostrarMensaje(lblMsgProducto, "Error: " + e.getMessage(), true); }
    }
    private void actualizarProducto() {
        if (selectedProdId == null) return;
        try (Connection con = new ConexionMySQL().conectar();
             PreparedStatement ps = con.prepareStatement("UPDATE productos SET nombre=?, precio=?, stock=?, tipo_talla=? WHERE id_producto=?")) {
            ps.setString(1, txtProdNombre.getText());
            ps.setDouble(2, Double.parseDouble(txtProdPrecio.getText()));
            ps.setInt(3, Integer.parseInt(txtProdStock.getText()));
            ps.setString(4, cbProdTipo.getSelectedItem().toString());
            ps.setString(5, selectedProdId); // WHERE
            ps.executeUpdate();
            mostrarMensaje(lblMsgProducto, "Producto actualizado.", false);
            cargarProductos(); limpiarFormProductos(); selectedProdId = null;
        } catch (Exception e) { mostrarMensaje(lblMsgProducto, "Error: " + e.getMessage(), true); }
    }
    private void eliminarProducto() {
        if (selectedProdId == null) return;
        try (Connection con = new ConexionMySQL().conectar();
             PreparedStatement ps = con.prepareStatement("DELETE FROM productos WHERE id_producto=?")) {
            ps.setString(1, selectedProdId);
            ps.executeUpdate();
            mostrarMensaje(lblMsgProducto, "Producto eliminado.", false);
            cargarProductos(); limpiarFormProductos(); selectedProdId = null;
        } catch (Exception e) { mostrarMensaje(lblMsgProducto, "Error: " + e.getMessage(), true); }
    }

    private void cargarPedidos() {
        modelPedidos.setRowCount(0);
        try (Connection con = new ConexionMySQL().conectar();
             ResultSet rs = con.createStatement().executeQuery("SELECT * FROM pedidos")) {
            while (rs.next()) {
                String estado = rs.getString("estado");
                if(estado == null) estado = "En Camino";
                modelPedidos.addRow(new Object[]{
                    rs.getInt("id_pedido"), rs.getString("nombre_cliente"), 
                    rs.getString("direccion_envio"), rs.getString("telefono"), 
                    rs.getDouble("monto_total"), rs.getString("fecha_pedido"), estado
                });
            }
        } catch (Exception e) {}
    }
    private void actualizarPedido() {
        if (selectedPedId == null) return;
        try (Connection con = new ConexionMySQL().conectar();
             PreparedStatement ps = con.prepareStatement("UPDATE pedidos SET nombre_cliente=?, direccion_envio=?, telefono=?, estado=? WHERE id_pedido=?")) {
            ps.setString(1, txtPedCliente.getText());
            ps.setString(2, txtPedDir.getText());
            ps.setString(3, txtPedTel.getText());
            ps.setString(4, cbPedEstado.getSelectedItem().toString());
            ps.setString(5, selectedPedId);
            ps.executeUpdate();
            mostrarMensaje(lblMsgPedido, "Pedido actualizado.", false);
            cargarPedidos(); selectedPedId = null;
        } catch (Exception e) { mostrarMensaje(lblMsgPedido, "Error: " + e.getMessage(), true); }
    }
    private void eliminarPedido() {
        if(selectedPedId == null) return;
        try (Connection con = new ConexionMySQL().conectar()) {
            PreparedStatement ps = con.prepareStatement("DELETE FROM pedidos WHERE id_pedido=?");
            ps.setString(1, selectedPedId);
            ps.executeUpdate();
            mostrarMensaje(lblMsgPedido, "Pedido borrado.", false);
            cargarPedidos(); limpiarFormPedidos(); selectedPedId = null;
        } catch (Exception e) { mostrarMensaje(lblMsgPedido, "Error: " + e.getMessage(), true); }
    }

    private void mostrarMensaje(JLabel label, String texto, boolean error) {
        label.setText(texto);
        label.setForeground(error ? COLOR_DANGER : COLOR_SUCCESS);
        label.setBackground(error ? new Color(253, 237, 236) : new Color(237, 253, 240));
        label.setOpaque(true);
        Timer t = new Timer(3000, e -> { label.setText(" "); label.setBackground(COLOR_BG_MAIN); });
        t.setRepeats(false); t.start();
    }

    private void limpiarFormUsuarios() { txtUserNombre.setText(""); txtUserEmail.setText(""); txtUserPass.setText(""); }
    private void limpiarFormDirecciones() { txtDirUserId.setText(""); txtDirNombre.setText(""); txtDirCalle.setText(""); txtDirTel.setText(""); }
    private void limpiarFormProductos() { txtProdNombre.setText(""); txtProdPrecio.setText(""); txtProdStock.setText(""); }
    private void limpiarFormPedidos() { txtPedCliente.setText(""); txtPedDir.setText(""); txtPedTel.setText(""); txtPedTotal.setText(""); }
    
    private JLabel crearLabelMensaje() { JLabel l = new JLabel(" ", SwingConstants.CENTER); l.setFont(new Font("Segoe UI", Font.BOLD, 13)); l.setOpaque(true); l.setBackground(COLOR_BG_MAIN); l.setPreferredSize(new Dimension(0, 40)); return l; }
    private JPanel crearPanelFormulario(String titulo) { JPanel p = new JPanel(); p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS)); p.setBackground(COLOR_SIDEBAR); p.setBorder(new CompoundBorder(new MatteBorder(0, 0, 0, 1, Color.LIGHT_GRAY), new EmptyBorder(20, 20, 20, 20))); JLabel l = new JLabel(titulo); l.setFont(new Font("Segoe UI", Font.BOLD, 20)); l.setForeground(COLOR_PRIMARY); l.setAlignmentX(Component.LEFT_ALIGNMENT); p.add(l); p.add(Box.createRigidArea(new Dimension(0, 25))); return p; }
    private JPanel crearPanelBotones() { JPanel p = new JPanel(new GridLayout(2, 2, 5, 5)); p.setBackground(COLOR_SIDEBAR); return p; }
    private JTextField crearTextField(boolean editable) { JTextField t = new JTextField(); t.setFont(new Font("Segoe UI", Font.PLAIN, 14)); t.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)), BorderFactory.createEmptyBorder(8, 8, 8, 8))); t.setEditable(editable); t.setBackground(editable ? Color.WHITE : new Color(245, 245, 245)); return t; }
    private void agregarCampo(JPanel panel, String etiqueta, JComponent campo) { JLabel l = new JLabel(etiqueta); l.setFont(new Font("Segoe UI", Font.BOLD, 12)); l.setForeground(COLOR_TEXT_LABEL); l.setAlignmentX(Component.LEFT_ALIGNMENT); campo.setAlignmentX(Component.LEFT_ALIGNMENT); campo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40)); panel.add(l); panel.add(Box.createRigidArea(new Dimension(0, 5))); panel.add(campo); panel.add(Box.createRigidArea(new Dimension(0, 15))); }
    private JButton crearBoton(String texto, Color bg) { JButton b = new JButton(texto); b.setFont(new Font("Segoe UI", Font.BOLD, 12)); b.setBackground(bg); b.setForeground(Color.WHITE); b.setFocusPainted(false); b.setBorderPainted(false); b.setCursor(new Cursor(Cursor.HAND_CURSOR)); b.setPreferredSize(new Dimension(0, 40)); return b; }
    
    private JTable crearTabla(DefaultTableModel modelo) { 
        JTable t = new JTable(modelo); 
        t.setRowHeight(35); 
        t.setFont(new Font("Segoe UI", Font.PLAIN, 14)); 
        t.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13)); 
        t.getTableHeader().setBackground(new Color(240, 240, 240)); 
        t.setShowVerticalLines(false); 
        t.setGridColor(new Color(230, 230, 230)); 
        t.setSelectionBackground(new Color(232, 240, 254)); 
        t.setSelectionForeground(Color.BLACK); 
        DefaultTableCellRenderer r = new DefaultTableCellRenderer(); 
        r.setHorizontalAlignment(JLabel.CENTER); 
        for(int i=0; i<t.getColumnCount(); i++) t.getColumnModel().getColumn(i).setCellRenderer(r); 
        return t; 
    }
    
    private JSplitPane crearSplit(JPanel form, JScrollPane scroll) { 
        JSplitPane s = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, form, scroll); 
        s.setDividerLocation(350); 
        s.setDividerSize(3); 
        s.setBorder(null); 
        return s; 
    }
    
    private void agregarValidacionNumerica(JTextField campo) { campo.addKeyListener(new KeyAdapter() { public void keyTyped(KeyEvent e) { if (!Character.isDigit(e.getKeyChar()) && e.getKeyChar() != '.' && e.getKeyChar() != KeyEvent.VK_BACK_SPACE) e.consume(); } }); }
}