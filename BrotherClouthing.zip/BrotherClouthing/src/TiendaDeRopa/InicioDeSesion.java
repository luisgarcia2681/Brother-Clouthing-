/*
 * PROYECTO: Brother Clothing
 * ALUMNO: Luis Gael Garcia Reyes
 * MATERIA: Analisis Y Diseño De Sistemas
 * FECHA: 30 de Noviembre 2025
 * DESCRIPCIÓN: Clase principal (Main) que inicia el programa. Gestiona el Login (Acceso) y el Registro de nuevos usuarios.
 */
package TiendaDeRopa;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.sql.*;

public class InicioDeSesion extends JFrame {
    private static final long serialVersionUID = 1L;

    private JPanel cards;
    private CardLayout cardLayout;
    private JTextField loginEmailField;
    private JPasswordField loginPasswordField;
    private JLabel loginStatusLabel;
    private JTextField regNameField, regEmailField;
    private JPasswordField regPasswordField;
    private JLabel regStatusLabel;

    private final Color COLOR_BG = new Color(245, 247, 249);
    private final Color COLOR_BTN_PRIMARY = new Color(70, 90, 100);
    private final Color COLOR_BTN_TEXT = Color.WHITE;
    private final Color COLOR_ERROR = new Color(192, 57, 43);
    private final Color COLOR_SUCCESS = new Color(39, 174, 96);

    public InicioDeSesion() {
        setTitle("Brother Clothing - Acceso");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(450, 450); 
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        cards = new JPanel(cardLayout);

        cards.add(createLoginPanel(), "login");
        cards.add(createRegisterPanel(), "register");

        add(cards);
        cardLayout.show(cards, "login");
    }

    private void estiloBoton(JButton btn) {
        btn.setBackground(COLOR_BTN_PRIMARY);
        btn.setForeground(COLOR_BTN_TEXT);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private JPanel createLoginPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBorder(new EmptyBorder(30, 40, 30, 40));
        panel.setBackground(COLOR_BG);

        JLabel title = new JLabel("Bienvenido", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(50, 50, 50));
        panel.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(4, 1, 10, 10));
        form.setBackground(COLOR_BG);

        form.add(new JLabel("Correo electrónico:"));
        loginEmailField = new JTextField();
        form.add(loginEmailField);

        form.add(new JLabel("Contraseña:"));
        loginPasswordField = new JPasswordField();
        form.add(loginPasswordField);

        panel.add(form, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new GridLayout(4, 1, 10, 5));
        bottom.setBackground(COLOR_BG);

        JButton loginButton = new JButton("INICIAR SESIÓN");
        estiloBoton(loginButton);
        
        JButton goToRegister = new JButton("Crear cuenta nueva");
        goToRegister.setContentAreaFilled(false);
        goToRegister.setBorderPainted(false);
        goToRegister.setForeground(COLOR_BTN_PRIMARY);
        
        JButton btnAdmin = new JButton("Acceso Administrativo");
        btnAdmin.setContentAreaFilled(false);
        btnAdmin.setBorderPainted(false);
        btnAdmin.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        btnAdmin.setForeground(Color.GRAY);
        
        loginStatusLabel = new JLabel(" ", SwingConstants.CENTER);
        loginStatusLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));

        bottom.add(loginStatusLabel);
        bottom.add(loginButton);
        bottom.add(goToRegister);
        bottom.add(btnAdmin);

        panel.add(bottom, BorderLayout.SOUTH);

        loginButton.addActionListener(e -> attemptLogin());
        goToRegister.addActionListener(e -> {
            loginStatusLabel.setText(" ");
            cardLayout.show(cards, "register");
        });
        
        btnAdmin.addActionListener(e -> {
            String pwd = JOptionPane.showInputDialog(this, "Contraseña de Administrador:");
            if ("admin123".equals(pwd)) {
                new AdminPanel().setVisible(true);
            } else if (pwd != null) {
                mostrarMensaje(loginStatusLabel, "Acceso denegado.", true);
            }
        });

        return panel;
    }

    private JPanel createRegisterPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBorder(new EmptyBorder(30, 40, 30, 40));
        panel.setBackground(COLOR_BG);

        JLabel title = new JLabel("Nueva Cuenta", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(50, 50, 50));
        panel.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(6, 1, 5, 5));
        form.setBackground(COLOR_BG);

        form.add(new JLabel("Nombre:"));
        regNameField = new JTextField(); form.add(regNameField);
        form.add(new JLabel("Correo electrónico:"));
        regEmailField = new JTextField(); form.add(regEmailField);
        form.add(new JLabel("Contraseña:"));
        regPasswordField = new JPasswordField(); form.add(regPasswordField);

        panel.add(form, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new GridLayout(3, 1, 10, 10));
        bottom.setBackground(COLOR_BG);

        JButton regButton = new JButton("REGISTRARSE");
        estiloBoton(regButton);

        JButton goToLogin = new JButton("Cancelar");
        goToLogin.setContentAreaFilled(false);
        goToLogin.setBorderPainted(false);
        goToLogin.setForeground(Color.GRAY);

        regStatusLabel = new JLabel(" ", SwingConstants.CENTER);
        regStatusLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));

        bottom.add(regStatusLabel);
        bottom.add(regButton);
        bottom.add(goToLogin);

        panel.add(bottom, BorderLayout.SOUTH);

        regButton.addActionListener(e -> attemptRegister());
        goToLogin.addActionListener(e -> {
            regStatusLabel.setText(" ");
            cardLayout.show(cards, "login");
        });

        return panel;
    }

    private void attemptLogin() {
        String email = loginEmailField.getText().trim();
        String password = new String(loginPasswordField.getPassword()).trim();

        if (email.isEmpty() || password.isEmpty()) {
            mostrarMensaje(loginStatusLabel, "Complete todos los campos.", true);
            return;
        }

        ConexionMySQL conexion = new ConexionMySQL();
        try (Connection con = conexion.conectar();
             PreparedStatement ps = con.prepareStatement("SELECT id, nombre FROM usuarios WHERE email = ? AND password = ?")) {
            
            ps.setString(1, email);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int userId = rs.getInt("id"); 
                    mostrarMensaje(loginStatusLabel, "¡Bienvenido! Cargando...", false);
                    Timer timer = new Timer(1000, e -> {
                        new MenuPrincipal(userId).setVisible(true);
                        this.dispose();
                    });
                    timer.setRepeats(false);
                    timer.start();
                } else {
                    mostrarMensaje(loginStatusLabel, "Credenciales incorrectas.", true);
                }
            }
        } catch (SQLException ex) {
            mostrarMensaje(loginStatusLabel, "Error de conexión.", true);
        }
    }

    private void attemptRegister() {
        String name = regNameField.getText().trim();
        String email = regEmailField.getText().trim();
        String password = new String(regPasswordField.getPassword()).trim();

        if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
            mostrarMensaje(regStatusLabel, "Complete todos los campos.", true);
            return;
        }

        ConexionMySQL conexion = new ConexionMySQL();
        try (Connection con = conexion.conectar();
             PreparedStatement ps = con.prepareStatement("INSERT INTO usuarios (nombre, email, password) VALUES (?, ?, ?)")) {
            
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, password);
            ps.executeUpdate();
            
            mostrarMensaje(regStatusLabel, "¡Cuenta creada! Inicie sesión.", false);
            regNameField.setText(""); regEmailField.setText(""); regPasswordField.setText("");
            
        } catch (SQLException ex) {
            if (ex.getErrorCode() == 1062) mostrarMensaje(regStatusLabel, "El correo ya existe.", true);
            else mostrarMensaje(regStatusLabel, "Error de base de datos.", true);
        }
    }

    private void mostrarMensaje(JLabel label, String texto, boolean esError) {
        label.setText(texto);
        label.setForeground(esError ? COLOR_ERROR : COLOR_SUCCESS);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new InicioDeSesion().setVisible(true));
    }
}