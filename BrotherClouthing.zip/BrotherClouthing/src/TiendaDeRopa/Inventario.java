/*
 * PROYECTO: Brother Clothing
 * ALUMNO: Luis Gael Garcia Reyes
 * MATERIA: Analisis Y Diseño De Sistemas
 * FECHA: 30 de Noviembre 2025
 * DESCRIPCIÓN: Clase lógica auxiliar para consultas rápidas de stock y actualizaciones específicas en la base de datos.
 */
package TiendaDeRopa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Inventario {

    public int consultarStock(String codigo) {
        int stock = 0;
        String sql = "SELECT stock FROM productos WHERE id_producto = ?"; 

        try (Connection con = new ConexionMySQL().conectar();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, codigo);
            
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    stock = rs.getInt("stock");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar stock: " + e.getMessage());
        }
        return stock;
    }

    public void actualizarStockPorVenta(String codigo, int cantidadVendida) {
        String sql = "UPDATE productos SET stock = stock - ? WHERE id_producto = ?";
        
        try (Connection con = new ConexionMySQL().conectar();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, cantidadVendida);
            pst.setString(2, codigo);
            
            pst.executeUpdate();
            
        } catch (SQLException e) {
            System.err.println("Error al actualizar stock: " + e.getMessage());
        }
    }
}