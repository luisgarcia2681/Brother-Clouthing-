/*
 * PROYECTO: Brother Clothing
 * ALUMNO: Luis Gael Garcia Reyes
 * MATERIA: Analisis Y Diseño De Sistemas
 * FECHA: 30 de Noviembre 2025
 * DESCRIPCIÓN: Clase utilitaria encargada de establecer la conexión JDBC con la base de datos 'BrotherClouthing'.
 */
package TiendaDeRopa;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ConexionMySQL {

    public Connection conectar() {
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/BrotherClouthing?serverTimezone=UTC";
            String usuario = "root";
            String contrasena = "@1UiSgAr1624"; 

            con = DriverManager.getConnection(url, usuario, contrasena);

        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error: No se encontró el Driver JDBC.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al conectar con la BD: " + e.getMessage());
        }
        return con;
    }
}