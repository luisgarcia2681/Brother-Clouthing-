/*
 * PROYECTO: Brother Clothing
 * ALUMNO: Luis Gael Garcia Reyes
 * MATERIA: Analisis Y Diseño De Sistemas
 * FECHA: 30 de Noviembre 2025
 * DESCRIPCIÓN: Vista de resumen del carrito de compras. Muestra la lista de artículos seleccionados antes de pasar a pagar.
 */
package TiendaDeRopa;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;

public class VistaOrden extends JFrame {

    private static final long serialVersionUID = 1L;
    private JTable tablaProductos;
    private DefaultTableModel tableModel;
    private JLabel lblTotalAmount;
    private int idUsuarioActual;
    
    private final Color COLOR_BG = new Color(245, 247, 249);
    private final Color COLOR_BTN_PRIMARY = new Color(70, 90, 100);
    private final Color COLOR_BTN_SUCCESS = new Color(46, 204, 113);

    public VistaOrden(String ordenTexto, int idUsuario) {
        this.idUsuarioActual = idUsuario;
        
        setTitle("Resumen de la Orden - Brother Clothing");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 650, 550);
        setLocationRelativeTo(null);

        JPanel contentPane = new JPanel(new BorderLayout(10, 10));
        contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
        contentPane.setBackground(COLOR_BG);
        setContentPane(contentPane);

        JLabel lblTitle = new JLabel("Confirma tu Orden", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(new Color(50, 50, 50));
        contentPane.add(lblTitle, BorderLayout.NORTH);

        String[] columnNames = {"", "Producto", "Talla", "Precio"};
        
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public Class<?> getColumnClass(int column) {
                return column == 0 ? Icon.class : Object.class;
            }
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tablaProductos = new JTable(tableModel);
        tablaProductos.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tablaProductos.setRowHeight(80);
        tablaProductos.setFillsViewportHeight(true);
        tablaProductos.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        tablaProductos.setShowVerticalLines(false);
        tablaProductos.setBackground(Color.WHITE);
        
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        tablaProductos.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
        tablaProductos.getColumnModel().getColumn(2).setCellRenderer(centerRenderer);
        tablaProductos.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
        
        tablaProductos.getColumnModel().getColumn(0).setPreferredWidth(80);
        tablaProductos.getColumnModel().getColumn(0).setMaxWidth(80);
        tablaProductos.getColumnModel().getColumn(0).setMinWidth(80);

        JScrollPane scrollPane = new JScrollPane(tablaProductos);
        scrollPane.getViewport().setBackground(COLOR_BG);
        scrollPane.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        contentPane.add(scrollPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout(10, 10));
        bottomPanel.setBackground(COLOR_BG);

        JPanel totalPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        totalPanel.setBackground(COLOR_BG);
        JLabel lblTotalText = new JLabel("Monto Total:");
        lblTotalText.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTotalAmount = new JLabel("$0.00");
        lblTotalAmount.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTotalAmount.setForeground(new Color(0, 100, 0));
        totalPanel.add(lblTotalText);
        totalPanel.add(lblTotalAmount);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(COLOR_BG);
        
        JButton btnVolver = new JButton("Seguir Comprando");
        estiloBoton(btnVolver, COLOR_BTN_PRIMARY);
        
        JButton btnPagar = new JButton("Proceder al Pago");
        estiloBoton(btnPagar, COLOR_BTN_SUCCESS);

        buttonPanel.add(btnVolver);
        buttonPanel.add(btnPagar);

        bottomPanel.add(totalPanel, BorderLayout.NORTH);
        bottomPanel.add(buttonPanel, BorderLayout.CENTER);
        contentPane.add(bottomPanel, BorderLayout.SOUTH);
        
        cargarProductosDesdeTexto(ordenTexto);

        btnVolver.addActionListener(e -> {
            Productos ventanaProductos = new Productos(ordenTexto, idUsuarioActual); 
            ventanaProductos.setVisible(true);
            this.dispose();
        });
        
        btnPagar.addActionListener(e -> {
            Compra ventanaCompra = new Compra(tableModel, lblTotalAmount.getText(), idUsuarioActual);
            ventanaCompra.setVisible(true);
            this.dispose();
        });
    }

    private void estiloBoton(JButton btn, Color color) {
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setPreferredSize(new Dimension(180, 45));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void cargarProductosDesdeTexto(String texto) {
        if (texto == null || texto.trim().isEmpty()) return;
        
        String[] lineas = texto.trim().split("\n");
        double total = 0.0;
        
        for (String linea : lineas) {
            String[] partsPrecio = linea.split(" - Precio: ");
            
            if (partsPrecio.length == 2) {
                String productoYTalla = partsPrecio[0];
                try {
                    String precioStr = partsPrecio[1].replace(',', '.');
                    double precio = Double.parseDouble(precioStr);
                    total += precio;

                    String[] partsTalla = productoYTalla.split(" - Talla: ");
                    if (partsTalla.length == 2) {
                        String producto = partsTalla[0].trim();
                        String talla = partsTalla[1].trim();
                        
                        ImageIcon icono = obtenerImagenProducto(producto);
                        
                        tableModel.addRow(new Object[]{icono, producto, talla, String.format("%.2f", precio)});
                    }
                } catch (NumberFormatException ex) {
                    System.err.println("Error al procesar línea: " + linea);
                }
            }
        }
        lblTotalAmount.setText(String.format("$%.2f", total));
    }

    private ImageIcon obtenerImagenProducto(String nombreProducto) {
        String rutaBase = "imagenesbrotherclouthing/"; 
        
        String archivo = "Basic.png"; 

        if (nombreProducto == null) return new ImageIcon();
        String nombreLower = nombreProducto.toLowerCase();

        if (nombreLower.contains("baby tee")) archivo = "Baby Tee.png";
        else if (nombreLower.contains("boxy")) archivo = "Boxy Fit.png";
        else if (nombreLower.contains("regular")) archivo = "Regular Fit.png";
        
        else if (nombreLower.contains("baggy")) archivo = "Baggy.png";
        else if (nombreLower.contains("flare")) archivo = "Flare.png";
        else if (nombreLower.contains("recto")) archivo = "Recto.png";
        
        else if (nombreLower.contains("chamarra")) archivo = "Chamarra.png";
        else if (nombreLower.contains("print")) archivo = "Sudadera Print.png";
        else if (nombreLower.contains("basica") || nombreLower.contains("básica")) archivo = "Basic.png";
        
        else if (nombreLower.contains("samba") || nombreLower.contains("adidas") || nombreLower.contains("tenis")) archivo = "Samba.png";
        else if (nombreLower.contains("dr. m") || nombreLower.contains("martens") || nombreLower.contains("zapatos")) archivo = "Dr. M.png";
        else if (nombreLower.contains("timbs") || nombreLower.contains("timberland") || nombreLower.contains("botas")) archivo = "Timbs.png";

        String rutaCompleta = rutaBase + archivo;
        
        try {
            File f = new File(rutaCompleta);
            if (f.exists()) {
                ImageIcon iconOriginal = new ImageIcon(rutaCompleta);
                Image imgEscalada = iconOriginal.getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
                return new ImageIcon(imgEscalada);
            }
        } catch (Exception e) {
        }
        return new ImageIcon(); 
    }
}