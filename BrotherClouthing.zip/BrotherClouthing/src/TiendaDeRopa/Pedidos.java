/*
 * PROYECTO: Brother Clothing
 * ALUMNO: Luis Gael Garcia Reyes
 * MATERIA: Analisis Y Diseño De Sistemas
 * FECHA: 30 de Noviembre 2025
 * DESCRIPCIÓN: Historial de compras del usuario. Permite visualizar el estado actual de los envíos (En Camino, Entregado, etc.).
 */
package TiendaDeRopa;

import java.awt.*;
import java.io.File;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class Pedidos extends JFrame {
    private static final long serialVersionUID = 1L;
    private final Color COLOR_BG = new Color(245, 247, 249);
    private int idUsuarioActual;
    private JTable table;

    public Pedidos(int idUsuario) {
        this.idUsuarioActual = idUsuario;
        
        setTitle("Mis Pedidos - Brother Clothing");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(750, 600);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(COLOR_BG);
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        headerPanel.setBackground(COLOR_BG);
        
        JLabel lblTitulo = new JLabel("Pedidos", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 28));
        lblTitulo.setForeground(new Color(50, 50, 50));
        headerPanel.add(lblTitulo);
        
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        String[] columnas = {"", "Producto", "Talla", "Precio", "Estado de Pedido"};
        
        DefaultTableModel model = new DefaultTableModel(columnas, 0) {
            @Override
            public Class<?> getColumnClass(int column) {
                return column == 0 ? Icon.class : Object.class;
            }
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        table.setRowHeight(80);
        table.setFillsViewportHeight(true);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        table.setBackground(Color.WHITE);
        
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setHorizontalAlignment(JLabel.CENTER);
                
                if (column == 4) {
                    String estado = (String) value;
                    setFont(new Font("Segoe UI", Font.BOLD, 14));
                    
                    if ("En Camino".equals(estado)) {
                        setForeground(new Color(255, 140, 0)); 
                    } else if ("Entregado".equals(estado)) {
                        setForeground(new Color(39, 174, 96));
                    } else if ("Cancelado".equals(estado)) {
                        setForeground(new Color(192, 57, 43));
                    } else {
                        setForeground(Color.BLACK);
                    }
                } else {
                    setForeground(Color.BLACK);
                    setFont(new Font("Segoe UI", Font.PLAIN, 14));
                }
                return c;
            }
        });

        table.getColumnModel().getColumn(0).setHeaderValue("");
        table.getColumnModel().getColumn(0).setPreferredWidth(80);
        table.getColumnModel().getColumn(0).setMaxWidth(80);
        table.getColumnModel().getColumn(0).setMinWidth(80);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.getViewport().setBackground(COLOR_BG); 
        scrollPane.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        cargarHistorialPedidos(model);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        bottomPanel.setBackground(COLOR_BG);
        
        JButton btnVolverMenu = new JButton("Volver al Menú");
        estiloBoton(btnVolverMenu, new Color(52, 73, 94));
        
        JButton btnProductos = new JButton("Nuevo Pedido");
        estiloBoton(btnProductos, new Color(46, 204, 113));
        
        btnVolverMenu.addActionListener(e -> {
            new MenuPrincipal(idUsuarioActual).setVisible(true);
            dispose();
        });

        btnProductos.addActionListener(e -> {
            new Productos(idUsuarioActual).setVisible(true);
            dispose();
        });
        
        bottomPanel.add(btnVolverMenu);
        bottomPanel.add(btnProductos);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        setContentPane(mainPanel);
    }

    private void estiloBoton(JButton btn, Color color) {
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setPreferredSize(new Dimension(160, 45));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void cargarHistorialPedidos(DefaultTableModel model) {
        ConexionMySQL conexion = new ConexionMySQL();
        
        String sql = "SELECT p.nombre, dp.talla, dp.precio_unitario, ped.id_pedido, ped.estado " +
                     "FROM detalle_pedido dp " +
                     "JOIN pedidos ped ON dp.id_pedido = ped.id_pedido " +
                     "JOIN productos p ON dp.id_producto = p.id_producto " +
                     "WHERE ped.id_usuario = ? ORDER BY ped.id_pedido DESC";

        try (Connection con = conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, idUsuarioActual);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String nombre = rs.getString("nombre");
                String talla = rs.getString("talla");
                String precio = String.format("%.2f", rs.getDouble("precio_unitario"));
                
                String estado = rs.getString("estado");
                if (estado == null || estado.isEmpty()) {
                    estado = "En Camino";
                }

                ImageIcon icono = obtenerImagenProducto(nombre);
                
                model.addRow(new Object[]{icono, nombre, talla, precio, estado});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar historial: " + e.getMessage());
        }
    }

    private ImageIcon obtenerImagenProducto(String nombreProducto) {
        String rutaBase = "imagenesbrotherclouthing/"; 
        
        String archivo = "Basic.png"; 
        
        if (nombreProducto == null) return new ImageIcon();

        String nombreLower = nombreProducto.toLowerCase();

        if (nombreLower.contains("baby tee")) archivo = "Baby Tee.png";
        else if (nombreLower.contains("baggy")) archivo = "Baggy.png";
        else if (nombreLower.contains("basic")) archivo = "Basic.png";
        else if (nombreLower.contains("boxy")) archivo = "Boxy Fit.png";
        else if (nombreLower.contains("chamarra")) archivo = "Chamarra.png";
        else if (nombreLower.contains("dr. m") || nombreLower.contains("martens")) archivo = "Dr. M.png";
        else if (nombreLower.contains("flare")) archivo = "Flare.png";
        else if (nombreLower.contains("recto")) archivo = "Recto.png";
        else if (nombreLower.contains("regular")) archivo = "Regular Fit.png";
        else if (nombreLower.contains("samba")) archivo = "Samba.png";
        else if (nombreLower.contains("sudadera") || nombreLower.contains("print")) archivo = "Sudadera Print.png";
        else if (nombreLower.contains("timbs") || nombreLower.contains("timberland")) archivo = "Timbs.png";

        String rutaCompleta = rutaBase + archivo;
        
        try {
            File f = new File(rutaCompleta);
            if (f.exists()) {
                ImageIcon iconOriginal = new ImageIcon(rutaCompleta);
                Image imgEscalada = iconOriginal.getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
                return new ImageIcon(imgEscalada);
            }
        } catch (Exception e) {
        }
        return new ImageIcon(); 
    }
}