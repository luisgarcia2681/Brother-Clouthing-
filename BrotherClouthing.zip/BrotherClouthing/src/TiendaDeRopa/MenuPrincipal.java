/*
 * PROYECTO: Brother Clothing
 * ALUMNO: Luis Gael Garcia Reyes
 * MATERIA: Analisis Y Diseño De Sistemas
 * FECHA: 30 de Noviembre 2025
 * DESCRIPCIÓN: Pantalla central de navegación para el cliente. Conecta el catálogo de productos con el historial de pedidos.
 */
package TiendaDeRopa;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class MenuPrincipal extends JFrame {

    private static final long serialVersionUID = 1L;
    private final Color COLOR_BG = new Color(245, 247, 249);
    private int idUsuarioActual;

    public MenuPrincipal(int idUsuario) {
        this.idUsuarioActual = idUsuario;
        
        setTitle("Menú Principal - Brother Clothing");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 400);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(COLOR_BG);
        mainPanel.setBorder(new EmptyBorder(30, 30, 30, 30));

        JLabel lblTitulo = new JLabel("Bienvenido a Brother Clothing", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitulo.setForeground(new Color(50, 50, 50));
        mainPanel.add(lblTitulo, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new GridLayout(2, 1, 15, 15));
        centerPanel.setBackground(COLOR_BG);
        centerPanel.setBorder(new EmptyBorder(20, 40, 20, 40));

        JButton btnNuevoPedido = createButton("Realizar Nuevo Pedido", "Productos");
        JButton btnVerPedidos = createButton("Ver Mis Pedidos", "Historial");

        centerPanel.add(btnNuevoPedido);
        centerPanel.add(btnVerPedidos);

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        JButton btnSalir = new JButton("Cerrar Sesión");
        btnSalir.setBackground(new Color(231, 76, 60));
        btnSalir.setForeground(Color.WHITE);
        btnSalir.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnSalir.setFocusPainted(false);
        btnSalir.addActionListener(e -> {
            new InicioDeSesion().setVisible(true);
            dispose();
        });
        
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.setBackground(COLOR_BG);
        bottomPanel.add(btnSalir);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        setContentPane(mainPanel);
    }

    private JButton createButton(String text, String tipo) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        if (tipo.equals("Productos")) {
            btn.setBackground(new Color(46, 204, 113)); 
            btn.setForeground(Color.WHITE);
            btn.addActionListener(e -> {
                new Productos(idUsuarioActual).setVisible(true);
                dispose();
            });
        } else {
            btn.setBackground(new Color(52, 152, 219)); 
            btn.setForeground(Color.WHITE);
            btn.addActionListener(e -> {
                new Pedidos(idUsuarioActual).setVisible(true);
                dispose();
            });
        }
        return btn;
    }
}