/*
 * PROYECTO: Brother Clothing
 * ALUMNO: Luis Gael Garcia Reyes
 * MATERIA: Analisis Y Diseño De Sistemas
 * FECHA: 30 de Noviembre 2025
 * DESCRIPCIÓN: Módulo de transacción final. Recopila datos de envío/pago, registra el pedido en la BD y actualiza el inventario.
 */
package TiendaDeRopa;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class Compra extends JFrame {
    private static final long serialVersionUID = 1L;

    private JTextField nombreField, direccionField, telefonoField;
    private JComboBox<String> metodoPagoCombo;
    private JComboBox<DireccionItem> cbDireccionesGuardadas;
    private JCheckBox chkGuardarDireccion;
    private JTextField numeroTarjetaField, vencimientoField, ccvField;
    private JPanel datosTarjetaPanel;
    private JTable productosTable;
    private DefaultTableModel tableModel;
    private JLabel totalLabel;
    private JLabel lblMensajeSistema;
    
    private final Color COLOR_BG = new Color(245, 247, 249);
    private final Color COLOR_ERROR = new Color(231, 76, 60);
    private final Color COLOR_SUCCESS = new Color(39, 174, 96);
    private int idUsuarioActual;

    public Compra(DefaultTableModel modelDeOrden, String total, int idUsuario) {
        this.idUsuarioActual = idUsuario;
        setTitle("Finalizar Compra");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setSize(850, 750);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(COLOR_BG);
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel topPanel = new JPanel(new GridLayout(2, 1));
        topPanel.setBackground(COLOR_BG);
        JLabel title = new JLabel("Confirmación de Datos", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblMensajeSistema = new JLabel("Complete los datos para finalizar.", SwingConstants.CENTER);
        lblMensajeSistema.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblMensajeSistema.setForeground(Color.GRAY);
        topPanel.add(title);
        topPanel.add(lblMensajeSistema);
        mainPanel.add(topPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new GridBagLayout()); 
        centerPanel.setBackground(COLOR_BG);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 1.0; gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 0, 5, 0);
        
        centerPanel.add(crearPanelEnvio(), gbc);
        
        gbc.gridy = 1;
        centerPanel.add(crearPanelPago(), gbc);

        gbc.gridy = 2; gbc.weighty = 1.0; gbc.fill = GridBagConstraints.BOTH; 
        centerPanel.add(crearPanelProductos(), gbc);

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout(10, 10));
        bottomPanel.setBackground(COLOR_BG);
        
        JPanel infoPanel = new JPanel(new BorderLayout());
        infoPanel.setBackground(COLOR_BG);
        
        chkGuardarDireccion = new JCheckBox("Guardar esta dirección para futuras compras");
        chkGuardarDireccion.setBackground(COLOR_BG);
        chkGuardarDireccion.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        
        JPanel totalPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        totalPanel.setBackground(COLOR_BG);
        totalLabel = new JLabel(total);
        totalLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        totalPanel.add(new JLabel("Total a Pagar: "));
        totalPanel.add(totalLabel);
        
        infoPanel.add(chkGuardarDireccion, BorderLayout.WEST);
        infoPanel.add(totalPanel, BorderLayout.EAST);

        JButton btnConfirmar = new JButton("CONFIRMAR ORDEN");
        btnConfirmar.setBackground(new Color(52, 73, 94));
        btnConfirmar.setForeground(Color.WHITE);
        btnConfirmar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnConfirmar.setPreferredSize(new Dimension(0, 50));
        btnConfirmar.setFocusPainted(false);

        bottomPanel.add(infoPanel, BorderLayout.NORTH);
        bottomPanel.add(btnConfirmar, BorderLayout.SOUTH);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        btnConfirmar.addActionListener(e -> confirmarOrden());

        setContentPane(mainPanel);

        for (int i = 0; i < modelDeOrden.getRowCount(); i++) {
            this.tableModel.addRow(new Object[]{
                modelDeOrden.getValueAt(i, 0), 
                modelDeOrden.getValueAt(i, 1), 
                modelDeOrden.getValueAt(i, 2), 
                modelDeOrden.getValueAt(i, 3) 
            });
        }
        
        cargarDireccionesUsuario();
    }

    private JPanel crearPanelEnvio() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Envío"));
        panel.setBackground(COLOR_BG);
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5,5,5,5); g.fill = GridBagConstraints.HORIZONTAL;

        g.gridx=0; g.gridy=0; g.weightx=0; panel.add(new JLabel("Mis Direcciones:"), g);
        cbDireccionesGuardadas = new JComboBox<>();
        cbDireccionesGuardadas.addItem(new DireccionItem(0, "Nueva Dirección...", "", "", ""));
        cbDireccionesGuardadas.addActionListener(e -> seleccionarDireccion());
        g.gridx=1; g.weightx=1.0; panel.add(cbDireccionesGuardadas, g);

        g.gridx=0; g.gridy=1; g.weightx=0; panel.add(new JLabel("Nombre:"), g);
        nombreField = new JTextField(20); g.gridx=1; g.weightx=1.0; panel.add(nombreField, g);

        g.gridx=0; g.gridy=2; g.weightx=0; panel.add(new JLabel("Dirección:"), g);
        direccionField = new JTextField(20); g.gridx=1; g.weightx=1.0; panel.add(direccionField, g);

        g.gridx=0; g.gridy=3; g.weightx=0; panel.add(new JLabel("Teléfono:"), g);
        telefonoField = new JTextField(20); 
        telefonoField.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                if (!Character.isDigit(e.getKeyChar()) || telefonoField.getText().length() >= 10) {
                    if (e.getKeyChar() != KeyEvent.VK_BACK_SPACE) e.consume();
                }
            }
        });
        g.gridx=1; g.weightx=1.0; panel.add(telefonoField, g);
        
        agregarListenerValidacion(nombreField);
        agregarListenerValidacion(direccionField);
        agregarListenerValidacion(telefonoField);
        return panel;
    }

    private void cargarDireccionesUsuario() {
        if (idUsuarioActual <= 0) return;
        ConexionMySQL conexion = new ConexionMySQL();
        try (Connection con = conexion.conectar();
             PreparedStatement ps = con.prepareStatement("SELECT id_direccion, nombre_destinatario, direccion, telefono FROM datos_envio WHERE id_usuario = ?")) {
            ps.setInt(1, idUsuarioActual);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                cbDireccionesGuardadas.addItem(new DireccionItem(
                    rs.getInt("id_direccion"), rs.getString("direccion"),
                    rs.getString("nombre_destinatario"), rs.getString("direccion"), rs.getString("telefono")
                ));
            }
        } catch (SQLException e) {}
    }

    private void seleccionarDireccion() {
        DireccionItem item = (DireccionItem) cbDireccionesGuardadas.getSelectedItem();
        if (item != null && item.getId() != 0) {
            nombreField.setText(item.getNombre());
            direccionField.setText(item.getDireccion());
            telefonoField.setText(item.getTelefono());
            chkGuardarDireccion.setSelected(false);
            chkGuardarDireccion.setEnabled(false);
            nombreField.setForeground(Color.BLACK);
            direccionField.setForeground(Color.BLACK);
            telefonoField.setForeground(Color.BLACK);
        } else {
            chkGuardarDireccion.setEnabled(true);
            chkGuardarDireccion.setSelected(true);
            nombreField.setText(""); direccionField.setText(""); telefonoField.setText("");
        }
    }

    private JPanel crearPanelPago() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Pago"));
        panel.setBackground(COLOR_BG);
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5,5,5,5); g.fill = GridBagConstraints.HORIZONTAL;

        g.gridx=0; g.gridy=0; panel.add(new JLabel("Método:"), g);
        metodoPagoCombo = new JComboBox<>(new String[]{"Tarjeta de crédito", "Tarjeta de débito"});
        g.gridx=1; g.weightx=1.0; panel.add(metodoPagoCombo, g);

        datosTarjetaPanel = new JPanel(new GridBagLayout());
        datosTarjetaPanel.setBackground(COLOR_BG);
        g.gridx=0; g.gridy=1; g.gridwidth=2; panel.add(datosTarjetaPanel, g);

        GridBagConstraints g2 = new GridBagConstraints();
        g2.insets = new Insets(4,4,4,4); g2.fill = GridBagConstraints.HORIZONTAL;
        
        g2.gridx=0; g2.gridy=0; datosTarjetaPanel.add(new JLabel("Número:"), g2);
        numeroTarjetaField = new JTextField(19); 
        numeroTarjetaField.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) { if (!Character.isDigit(e.getKeyChar()) && e.getKeyChar() != KeyEvent.VK_BACK_SPACE) e.consume(); }
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() != KeyEvent.VK_BACK_SPACE) {
                    String text = numeroTarjetaField.getText().replace(" ", "");
                    StringBuilder formatted = new StringBuilder();
                    for (int i = 0; i < text.length(); i++) {
                        if (i > 0 && i % 4 == 0) formatted.append(" ");
                        formatted.append(text.charAt(i));
                    }
                    if (formatted.length() > 19) numeroTarjetaField.setText(formatted.substring(0, 19));
                    else numeroTarjetaField.setText(formatted.toString());
                }
            }
        });
        g2.gridx=1; g2.weightx=1.0; datosTarjetaPanel.add(numeroTarjetaField, g2);
        
        g2.gridx=0; g2.gridy=1; g2.weightx=0; datosTarjetaPanel.add(new JLabel("Vence:"), g2);
        vencimientoField = new JTextField(5); 
        vencimientoField.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) { if (!Character.isDigit(e.getKeyChar()) && e.getKeyChar() != KeyEvent.VK_BACK_SPACE && e.getKeyChar() != '/') e.consume(); }
            public void keyReleased(KeyEvent e) {
                String text = vencimientoField.getText();
                if (text.length() == 2 && e.getKeyCode() != KeyEvent.VK_BACK_SPACE) vencimientoField.setText(text + "/");
                if (text.length() > 5) vencimientoField.setText(text.substring(0, 5));
            }
        });
        g2.gridx=1; g2.weightx=1.0; datosTarjetaPanel.add(vencimientoField, g2);
        
        g2.gridx=0; g2.gridy=2; g2.weightx=0; datosTarjetaPanel.add(new JLabel("CCV:"), g2);
        ccvField = new JTextField(3); 
        ccvField.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                if (!Character.isDigit(e.getKeyChar()) || ccvField.getText().length() >= 3) {
                    if (e.getKeyChar() != KeyEvent.VK_BACK_SPACE) e.consume();
                }
            }
        });
        g2.gridx=1; g2.weightx=1.0; datosTarjetaPanel.add(ccvField, g2);

        agregarListenerValidacion(numeroTarjetaField);
        agregarListenerValidacion(vencimientoField);
        agregarListenerValidacion(ccvField);
        return panel;
    }

    private JPanel crearPanelProductos() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Productos"));
        panel.setBackground(COLOR_BG);
        String[] cols = {"Img", "Producto", "Talla", "Precio"};
        tableModel = new DefaultTableModel(cols, 0) {
            public Class<?> getColumnClass(int column) { return column == 0 ? Icon.class : Object.class; }
            public boolean isCellEditable(int row, int column) { return false; }
        };
        productosTable = new JTable(tableModel);
        productosTable.setRowHeight(60);
        productosTable.setFillsViewportHeight(true);
        panel.add(new JScrollPane(productosTable), BorderLayout.CENTER);
        return panel;
    }

    private void agregarListenerValidacion(JTextField field) {
        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (field.getText().equals("Campo Incompleto")) {
                    field.setText(""); field.setForeground(Color.BLACK);
                }
            }
        });
    }

    private void confirmarOrden() {
        boolean valid = true;
        if (checkEmpty(nombreField)) valid = false;
        if (checkEmpty(direccionField)) valid = false;
        if (checkEmpty(telefonoField)) valid = false;
        if (checkEmpty(numeroTarjetaField)) valid = false;
        if (checkEmpty(vencimientoField)) valid = false;
        if (checkEmpty(ccvField)) valid = false;

        if (!valid) {
            lblMensajeSistema.setText("Corrija los campos marcados en rojo.");
            lblMensajeSistema.setForeground(COLOR_ERROR);
            return;
        }

        ConexionMySQL conexion = new ConexionMySQL();
        Connection con = null;

        try {
            con = conexion.conectar();
            con.setAutoCommit(false); 

            String sqlPedido = "INSERT INTO pedidos (nombre_cliente, direccion_envio, telefono, monto_total, metodo_pago, id_usuario) VALUES (?, ?, ?, ?, ?, ?)";
            int idPedidoGenerado = 0;
            try (PreparedStatement psPedido = con.prepareStatement(sqlPedido, Statement.RETURN_GENERATED_KEYS)) {
                psPedido.setString(1, nombreField.getText());
                psPedido.setString(2, direccionField.getText());
                psPedido.setString(3, telefonoField.getText());
                psPedido.setDouble(4, Double.parseDouble(totalLabel.getText().replace("$", "").replace(",", ".")));
                psPedido.setString(5, (String) metodoPagoCombo.getSelectedItem());
                psPedido.setInt(6, idUsuarioActual);
                psPedido.executeUpdate();
                try (ResultSet rs = psPedido.getGeneratedKeys()) { if (rs.next()) idPedidoGenerado = rs.getInt(1); }
            }

            String sqlDetalle = "INSERT INTO detalle_pedido (id_pedido, id_producto, talla, precio_unitario) VALUES (?, ?, ?, ?)";
            String sqlIdProd = "SELECT id_producto FROM productos WHERE nombre = ?";
            String sqlUpdateStock = "UPDATE productos SET stock = stock - 1 WHERE id_producto = ?";
            
            try (PreparedStatement psDetalle = con.prepareStatement(sqlDetalle);
                 PreparedStatement psId = con.prepareStatement(sqlIdProd);
                 PreparedStatement psUpdate = con.prepareStatement(sqlUpdateStock)) {

                for (int i = 0; i < tableModel.getRowCount(); i++) {
                    String nombre = tableModel.getValueAt(i, 1).toString();
                    psId.setString(1, nombre);
                    
                    int idProd = -1;
                    try (ResultSet rsId = psId.executeQuery()) { if (rsId.next()) idProd = rsId.getInt("id_producto"); }

                    if (idProd != -1) {
                        psDetalle.setInt(1, idPedidoGenerado);
                        psDetalle.setInt(2, idProd);
                        psDetalle.setString(3, tableModel.getValueAt(i, 2).toString());
                        psDetalle.setDouble(4, Double.parseDouble(tableModel.getValueAt(i, 3).toString().replace(',', '.')));
                        psDetalle.addBatch();

                        psUpdate.setInt(1, idProd);
                        psUpdate.addBatch();
                    }
                }
                psDetalle.executeBatch();
                psUpdate.executeBatch();
            }

            if (chkGuardarDireccion.isSelected() && chkGuardarDireccion.isEnabled() && idUsuarioActual > 0) {
                String sqlDir = "INSERT INTO datos_envio (id_usuario, nombre_destinatario, direccion, telefono) VALUES (?, ?, ?, ?)";
                try (PreparedStatement psDir = con.prepareStatement(sqlDir)) {
                    psDir.setInt(1, idUsuarioActual);
                    psDir.setString(2, nombreField.getText());
                    psDir.setString(3, direccionField.getText());
                    psDir.setString(4, telefonoField.getText());
                    psDir.executeUpdate();
                }
            }

            con.commit(); 
            lblMensajeSistema.setText("¡Éxito! Redirigiendo a tus pedidos...");
            lblMensajeSistema.setForeground(COLOR_SUCCESS);
            
            Timer t = new Timer(1500, e -> {
                new Pedidos(idUsuarioActual).setVisible(true);
                this.dispose();
            });
            t.setRepeats(false); t.start();

        } catch (SQLException ex) {
            try { if (con != null) con.rollback(); } catch (SQLException e) {}
            lblMensajeSistema.setText("Error BD: " + ex.getMessage());
            lblMensajeSistema.setForeground(COLOR_ERROR);
        } finally {
            try { if (con != null) con.close(); } catch (SQLException e) {}
        }
    }

    private boolean checkEmpty(JTextField f) {
        if (f.getText().trim().isEmpty() || f.getText().equals("Campo Incompleto")) {
            f.setText("Campo Incompleto"); f.setForeground(COLOR_ERROR);
            return true;
        }
        return false;
    }

    class DireccionItem {
        private int id;
        private String label, nombre, direccion, telefono;
        public DireccionItem(int id, String label, String nombre, String direccion, String telefono) {
            this.id = id; this.label = label; this.nombre = nombre; this.direccion = direccion; this.telefono = telefono;
        }
        public int getId() { return id; }
        public String getNombre() { return nombre; }
        public String getDireccion() { return direccion; }
        public String getTelefono() { return telefono; }
        public String toString() { return label; }
    }
}