CREATE DATABASE IF NOT EXISTS brotherclouthing;
USE brotherclouthing;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS detalle_pedido;
DROP TABLE IF EXISTS pedidos;
DROP TABLE IF EXISTS datos_envio;
DROP TABLE IF EXISTS productos;
DROP TABLE IF EXISTS usuarios;

CREATE TABLE usuarios (
  id int NOT NULL AUTO_INCREMENT,
  nombre varchar(100) NOT NULL,
  email varchar(100) NOT NULL,
  password varchar(255) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE productos (
  id_producto int NOT NULL AUTO_INCREMENT,
  nombre varchar(100) NOT NULL,
  precio decimal(10,2) NOT NULL,
  tipo_talla enum('ropa','calzado') NOT NULL,
  stock int NOT NULL DEFAULT '0',
  PRIMARY KEY (id_producto)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO productos VALUES 
(1,'Sudadera Basica',800.00,'ropa',50),
(2,'Camisa Baby Tee',600.00,'ropa',50),
(3,'Sudadera con Print',900.00,'ropa',50),
(4,'Zapatos Dr Martens',700.00,'calzado',50),
(5,'Camisa Regular Fit',550.00,'ropa',50),
(6,'Camisa Boxy Fit',450.00,'ropa',50),
(7,'Pantalon Flared',850.00,'ropa',50),
(8,'Pantalon Baggy',750.00,'ropa',50),
(9,'Pantalon Recto',700.00,'ropa',50),
(10,'Tenis Adidas',2200.00,'calzado',50),
(11,'Botas Timberland',4000.00,'calzado',50),
(12,'Chamarra Basica',1200.00,'ropa',50);

CREATE TABLE pedidos (
  id_pedido int NOT NULL AUTO_INCREMENT,
  nombre_cliente varchar(100) NOT NULL,
  direccion_envio varchar(255) NOT NULL,
  telefono varchar(20) DEFAULT NULL,
  monto_total decimal(10,2) NOT NULL,
  metodo_pago varchar(50) DEFAULT NULL,
  fecha_pedido timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  id_usuario int NOT NULL,
  estado varchar(50) DEFAULT 'En Camino',
  PRIMARY KEY (id_pedido),
  KEY fk_pedidos_usuario (id_usuario),
  CONSTRAINT fk_pedidos_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE detalle_pedido (
  id_detalle int NOT NULL AUTO_INCREMENT,
  id_pedido int NOT NULL,
  id_producto int NOT NULL,
  talla varchar(10) NOT NULL,
  cantidad int DEFAULT '1',
  precio_unitario decimal(10,2) NOT NULL,
  PRIMARY KEY (id_detalle),
  KEY id_producto (id_producto),
  KEY fk_detalle_pedido (id_pedido),
  CONSTRAINT detalle_pedido_ibfk_2 FOREIGN KEY (id_producto) REFERENCES productos (id_producto),
  CONSTRAINT fk_detalle_pedido FOREIGN KEY (id_pedido) REFERENCES pedidos (id_pedido) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE datos_envio (
  id_direccion int NOT NULL AUTO_INCREMENT,
  id_usuario int NOT NULL,
  nombre_destinatario varchar(100) NOT NULL,
  direccion text NOT NULL,
  telefono varchar(15) NOT NULL,
  PRIMARY KEY (id_direccion),
  KEY id_usuario (id_usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;